let tilemap = [ //NOTE: It's an array that contains 5 elements: 5 more arrays!
//      X AXIS
//   0  1  2  3  4    
    [0, 0, 0, 0, 0],//0
    [0, 0, 0, 0, 0],//1
    [0, 0, 0, 0, 0],//2    Y AXIS
    [0, 0, 1, 0, 0],//3
    [0, 0, 0, 2, 0] //4
]

function setup() {
    console.log(tilemap[3][2]) //will print 1 to console.
    //write your console.log line to access number 2 here
}